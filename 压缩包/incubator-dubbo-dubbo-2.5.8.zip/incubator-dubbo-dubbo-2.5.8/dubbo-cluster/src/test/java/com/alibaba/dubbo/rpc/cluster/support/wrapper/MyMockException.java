package com.alibaba.dubbo.rpc.cluster.support.wrapper;


public class MyMockException extends RuntimeException {

    private static final long serialVersionUID = 2851692379597990457L;

    public MyMockException(String message) {
        super(message);
    }

}
